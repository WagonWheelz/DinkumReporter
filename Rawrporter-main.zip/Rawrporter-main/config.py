# config.py
USERNAME = "REPLACEME.bsky.social"         # Your Bluesky username (e.g., yourname.bsky.social)
APP_PASSWORD = "REPLACEME"     # Your Bluesky app password
